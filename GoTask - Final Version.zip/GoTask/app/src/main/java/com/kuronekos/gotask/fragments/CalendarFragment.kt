package com.kuronekos.gotask.fragments

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CalendarView
import android.widget.TextView
import com.kuronekos.gotask.R
import com.kuronekos.gotask.databinding.FragmentCalendarBinding
import java.util.*

class CalendarFragment : Fragment() {

    private lateinit var binding: FragmentCalendarBinding
    private lateinit var calendarView: CalendarView
    private lateinit var dateView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentCalendarBinding.inflate(inflater, container, false)

        binding.cvCalender.setOnDateChangeListener(CalendarView.OnDateChangeListener {
            _, year, month, dayOfMonth ->
            val date = dayOfMonth.toString() + "-" + (month + 1) + "-" + year
            binding.tvDate.text = date
        })

        return binding.root
    }

}