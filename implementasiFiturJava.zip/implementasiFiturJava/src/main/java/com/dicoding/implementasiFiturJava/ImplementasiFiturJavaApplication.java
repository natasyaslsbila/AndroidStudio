package com.dicoding.implementasiFiturJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImplementasiFiturJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImplementasiFiturJavaApplication.class, args);
	}

}
