var hargaSabun1 = 50000;
var hargaSabun2 = 50000;
var hargaMasker1 = 7000;
var hargaMasker2 = 6000;

document.getElementById("hargaSabun1").innerHTML = hargaSabun1;
document.getElementById("hargaSabun2").innerHTML = hargaSabun2;
document.getElementById("hargaMasker1").innerHTML = hargaMasker1;
document.getElementById("hargaMasker2").innerHTML = hargaMasker2;

const addItem1=()=> {
    var item1 = document.getElementById('item1');
    value = parseInt(item1.getAttribute('value'), 10) + 1;
    item1.setAttribute('value', value);
    item1.innerHTML = value;
}
const minItem1=()=> {
    var item1 = document.getElementById('item1');
    value = parseInt(item1.getAttribute('value'), 10) - 1;
    item1.setAttribute('value', value);
    item1.innerHTML = value;
}

const addItem2 =()=> {
    var item2 = document.getElementById('item2');
    value = parseInt(item2.getAttribute('value'), 10) + 1;
    item2.setAttribute('value', value);
    item2.innerHTML = value;
}
const minItem2=()=> {
    var item2 = document.getElementById('item2');
    value = parseInt(item2.getAttribute('value'), 10) - 1;
    item2.setAttribute('value', value);
    item2.innerHTML = value;
}

const addItem3=()=> {
    var item3 = document.getElementById('item3');
    value = parseInt(item3.getAttribute('value'), 10) + 1;
    item3.setAttribute('value', value);
    item3.innerHTML = value;
}
const minItem3=()=> {
    var item3 = document.getElementById('item3');
    value = parseInt(item3.getAttribute('value'), 10) - 1;
    item3.setAttribute('value', value);
    item3.innerHTML = value;
}

const addItem4=()=> {
    var item4 = document.getElementById('item4');
    value = parseInt(item4.getAttribute('value'), 10) + 1;
    item4.setAttribute('value', value);
    item4.innerHTML = value;
}
const minItem4=()=> {
    var item4 = document.getElementById('item4');
    value = parseInt(item4.getAttribute('value'), 10) - 1;
    item4.setAttribute('value', value);
    item4.innerHTML = value;
}


function total() {

    var sabun1 = document.getElementById('item1');
    var sabun2 = document.getElementById('item2');
    var masker1 = document.getElementById('item3');
    var masker2 = document.getElementById('item4');

    var item1 = document.getElementById('totalItem1');
    item1.innerHTML = parseInt(sabun1.getAttribute('value'));
    var item2 = document.getElementById('totalItem2');
    item2.innerHTML = parseInt(sabun2.getAttribute('value'));
    var item3 = document.getElementById('totalItem3');
    item3.innerHTML = parseInt(masker1.getAttribute('value'));
    var item4 = document.getElementById('totalItem4');
    item4.innerHTML = parseInt(masker2.getAttribute('value'));

    var hargaSabun1 = 50000 * parseInt(sabun1.getAttribute('value'));
    var hargaSabun2 = 50000 * parseInt(sabun2.getAttribute('value'));
    var hargaMasker1 = 7000 * parseInt(masker1.getAttribute('value'));
    var hargaMasker2 = 6000 * parseInt(masker2.getAttribute('value'));

    var totalSemua = hargaSabun1 + hargaSabun2 + hargaMasker1 + hargaMasker2;

    totalSabun1 = document.getElementById('totalPrice1');
    totalSabun1.innerHTML = hargaSabun1;
    totalSabun2 = document.getElementById('totalPrice2');
    totalSabun2.innerHTML = hargaSabun2;
    totalMasker1 = document.getElementById('totalPrice3');
    totalMasker1.innerHTML = hargaMasker1;
    totalMasker2 = document.getElementById('totalPrice4');
    totalMasker2.innerHTML = hargaMasker2;

    var total = document.getElementById('total');
    total.innerHTML = totalSemua;
}