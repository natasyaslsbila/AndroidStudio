package com.kuronekos.gotask.adapters

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class ViewPagerAdapter(supportFragmentManager: FragmentManager) :
    FragmentPagerAdapter(supportFragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    private val mFragmentlist = ArrayList<Fragment>()
    private val mFragmentTitlelist = ArrayList<String>()

    override fun getCount(): Int {
        return mFragmentlist.size
    }

    override fun getItem(position: Int): Fragment {
        return mFragmentlist[position]
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return mFragmentTitlelist[position]
    }

    fun addFragment(fragment: Fragment, title: String) {
        mFragmentlist.add(fragment)
        mFragmentTitlelist.add(title)
    }

}