package com.kuronekos.gotask.database

data class Task(
    val taskId: String?,
    val user: String?,
    val title: String?,
    val description: String?,
    val completed: Boolean = false,
    val date: String?
) {
    constructor(): this("", "", "", "", false, "") {
    }
}

