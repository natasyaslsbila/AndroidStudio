package com.kuronekos.gotask

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.kuronekos.gotask.database.Task
import com.kuronekos.gotask.databinding.ActivityAddTaskBinding
import java.util.*

class AddTaskActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddTaskBinding

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var ref: DatabaseReference

    private lateinit var userId: String
    private lateinit var user: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        userId = auth.currentUser?.uid.toString()
        user = auth.currentUser?.email.toString()

        database = FirebaseDatabase.getInstance()
        ref = database.getReference("Task/users/$userId")

        binding.btnDone.setOnClickListener {
            addNewTask()
//            finish()
        }
        binding.btnDate.setOnClickListener {
            pickDate()
        }
    }

    private fun addNewTask() {
        val title = binding.edtTitle.editText?.text.toString().trim()
        val description = binding.edtDescription.editText?.text.toString().trim()
        val date = binding.btnDate.text.toString()

        if (title.isEmpty()) {
            binding.edtTitle.error = "Please enter this field!"
            return
        }
        if (description.isEmpty()) {
            binding.edtDescription.error = "Please enter this field!"
            return
        }

        val taskId = ref.push().key
        val task = Task(taskId, user, title, description, completed = false, date)

        if (taskId != null) {
            ref.child(taskId).setValue(task).addOnCompleteListener {
                finish()
                Toast.makeText(applicationContext, "Add Data Success", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }

    private fun pickDate() {
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        val monthNumber = arrayOf<String>(
            "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12",
        )

        val dpd =
            DatePickerDialog(this, DatePickerDialog.OnDateSetListener { view, mYear, mMonth, mDay ->
                val realMonth = monthNumber[mMonth]
                binding.btnDate.setText("" + mDay + "/" + realMonth + "/" + mYear)
            }, year, month, day)
        dpd.show()

    }
}