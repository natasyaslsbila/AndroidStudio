package com.kuronekos.gotask

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import com.google.firebase.auth.FirebaseAuth
import com.kuronekos.gotask.adapters.ViewPagerAdapter
import com.kuronekos.gotask.databinding.ActivityMainBinding
import com.kuronekos.gotask.fragments.CalendarFragment
import com.kuronekos.gotask.fragments.TaskFragment
import com.kuronekos.gotask.menu.AboutActivity
import com.kuronekos.gotask.menu.ProfileActivity

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        setUpTabs()
    }

    private fun setUpTabs() {
        val adapter = ViewPagerAdapter(supportFragmentManager)
        adapter.addFragment(TaskFragment(), "Task")
        adapter.addFragment(CalendarFragment(), "Calendar")
        binding.viewPager.adapter = adapter
        binding.tabLayout.setupWithViewPager(binding.viewPager)

        binding.tabLayout.getTabAt(0)!!.setIcon(R.drawable.ic_check_box)
        binding.tabLayout.getTabAt(1)!!.setIcon(R.drawable.ic_date_range)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection
        return when (item.itemId) {
            R.id.about_menu -> {
                Intent(this@MainActivity, AboutActivity::class.java).also {
                    startActivity(it)
                }
                true
            }
            R.id.acc_menu -> {
                Intent(this@MainActivity, ProfileActivity::class.java).also {
                    startActivity(it)
                }
                true
            }
            R.id.logout_menu -> {
                logout()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun logout() {
        auth.signOut()
        Intent(this@MainActivity, LoginActivity::class.java).also {
            it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(it)
            finish()
        }
    }
}