package com.kuronekos.gotask.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.kuronekos.gotask.AddTaskActivity
import com.kuronekos.gotask.R
import com.kuronekos.gotask.adapters.TaskAdapter
import com.kuronekos.gotask.database.Task
import com.kuronekos.gotask.databinding.FragmentTaskBinding


class TaskFragment : Fragment() {

    private lateinit var binding: FragmentTaskBinding

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var ref: DatabaseReference

    private lateinit var userId: String
    private lateinit var taskList: ArrayList<Task>


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentTaskBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.fabAddTask.setOnClickListener {
            Intent(activity, AddTaskActivity::class.java).also {
                startActivity(it)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Log.i("Log - OnResume", "Activated")
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()

        userId = auth.currentUser?.uid.toString()

        ref = database.getReference("Task/users/$userId")

        binding.rvRecyclerview.setHasFixedSize(true)
        binding.rvRecyclerview.layoutManager = LinearLayoutManager(context)

        taskList = arrayListOf<Task>()

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                taskList.clear()
                if (snapshot.exists()) {
                    taskList.clear()
                    for (h in snapshot.children) {
                        val task = h.getValue(Task::class.java)
                        taskList.add(task!!)
                    }
                    val adapter = TaskAdapter(context!!, taskList)
                    binding.rvRecyclerview.adapter = adapter
                } else {
                    val adapter = TaskAdapter(context!!, taskList)
                    binding.rvRecyclerview.adapter = adapter
                }
            }

            override fun onCancelled(error: DatabaseError) {
                return
            }

        })
    }
}