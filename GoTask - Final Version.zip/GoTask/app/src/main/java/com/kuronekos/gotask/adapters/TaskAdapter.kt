package com.kuronekos.gotask.adapters

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.kuronekos.gotask.R
import com.kuronekos.gotask.database.Task
import java.util.*
import kotlin.collections.ArrayList

class TaskAdapter(val context: Context, val taskList: ArrayList<Task>) :
    RecyclerView.Adapter<TaskAdapter.Holder>() {

    inner class Holder(view: View?) : RecyclerView.ViewHolder(view!!) {
        val title: TextView? = view?.findViewById(R.id.item_title)
        val date: TextView? = view?.findViewById(R.id.item_date)

        fun bind(task: Task, context: Context) {
            title?.text = task.title
            title?.paint?.isStrikeThruText = task.completed
            date?.text = task.date
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_layout, parent, false)
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.bind(taskList[position], context)
        val id = taskList[holder.adapterPosition].taskId
        val title = taskList[holder.adapterPosition].title
        val desc = taskList[holder.adapterPosition].description
        val date = taskList[holder.adapterPosition].date
        val completed = taskList[holder.adapterPosition].completed

        holder.itemView.setOnClickListener{
            showUpdateDialog(id, title, desc, date, completed)
        }
    }

    private fun showUpdateDialog(id: String?, title: String?, desc: String?, date: String?, completed: Boolean?) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Task Detail")

        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.update_dialog, null)

        val tvDateDialog = view.findViewById<TextView>(R.id.tv_date_dialog)
        val edtTitleDialog = view.findViewById<TextInputLayout>(R.id.edt_title_dialog)
        val edtDescDialog = view.findViewById<TextInputLayout>(R.id.edt_desc_dialog)
        val btnChangeDate = view.findViewById<Button>(R.id.btn_change_date)

        tvDateDialog.text = date
        edtTitleDialog.editText?.setText(title)
        edtDescDialog.editText?.setText(desc)
        btnChangeDate.setOnClickListener {
            val c = Calendar.getInstance()
            val year = c.get(Calendar.YEAR)
            val month = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)
            val monthNumber = arrayOf<String>(
                "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12",
            )

            val dpd =
                DatePickerDialog(context, DatePickerDialog.OnDateSetListener { view, mYear, mMonth, mDay ->
                    val realMonth = monthNumber[mMonth]
                    tvDateDialog.setText("" + mDay + "/" + realMonth + "/" + mYear)
                }, year, month, day)
            dpd.show()
        }

        val userId = FirebaseAuth.getInstance().currentUser?.uid.toString()
        val user = FirebaseAuth.getInstance().currentUser?.email.toString()
        val dbTask = FirebaseDatabase.getInstance().getReference("Task/users/$userId")

        builder.setView(view)
        builder.setPositiveButton("Save") {p0, p1 ->
            val newTitle = edtTitleDialog.editText?.text.toString().trim()
            val newDesc = edtDescDialog.editText?.text.toString().trim()
            val newDate = tvDateDialog.text.toString()
            if (newTitle.isEmpty()) {
                edtTitleDialog.error = "This field is required!"
                edtTitleDialog.requestFocus()
                return@setPositiveButton
            }
            if (newDesc.isEmpty()) {
                edtDescDialog.error = "This field is required!"
                edtDescDialog.requestFocus()
                return@setPositiveButton
            }
            val task = Task(id, user, newTitle, newDesc, completed = false, newDate)
            dbTask.child(id!!).setValue(task)
            Toast.makeText(context, "Update Data Success", Toast.LENGTH_SHORT)
                .show()
        }
        builder.setNegativeButton("Delete") {p0, p1 ->
            dbTask.child(id!!).removeValue()
            Toast.makeText(context, "Task : " + title + " is Deleted", Toast.LENGTH_SHORT)
                .show()
        }
        builder.setNeutralButton("Done") {p0, p1 ->
            val task = Task(id, user, title, desc, completed = true, date)
            dbTask.child(id!!).setValue(task)

            Toast.makeText(context, "Task : " + title + " is Done", Toast.LENGTH_SHORT)
                .show()
        }

        val alert = builder.create()
        alert.show()
    }

    override fun getItemCount(): Int {
        return taskList.size
    }
}